function Illumination() {

    this.ambient = new Color();
}
