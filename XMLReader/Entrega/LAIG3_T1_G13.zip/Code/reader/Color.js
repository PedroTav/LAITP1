function Color() {

    this.r = 0.0;
    this.g = 0.0;
    this.b = 0.0;
    this.a = 0.0;
}
