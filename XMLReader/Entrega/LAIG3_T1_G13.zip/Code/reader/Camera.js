function Camera() {

    this.near = 0.0;
    this.far = 0.0;
    this.angle = 0.0;
    this.to = new Coords();
    this.from = new Coords();
}
