/**
 * Animation
 * @constructor
 */
 function Animation() {
 	this.over = false;
 };


 Animation.prototype.constructor = Animation;

