function MyPrimitive(scene, id)
{
    CGFobject.call(this,scene);

    this.id = id;
}
